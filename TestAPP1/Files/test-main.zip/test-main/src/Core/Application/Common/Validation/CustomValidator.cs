namespace FSH.WebApi.Application.Common.Validation;

public class CustomValidator<T> : AbstractValidator<T>
{
}