﻿namespace FSH.WebApi.Shared.Events;

public interface IEvent
{
}