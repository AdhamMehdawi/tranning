﻿namespace FSH.WebApi.Shared.Notifications;

public static class NotificationConstants
{
    // The name of the method that's used to send notification messages from the server to the client
    public const string NotificationFromServer = nameof(NotificationFromServer);
}