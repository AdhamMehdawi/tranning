﻿namespace FSH.WebApi.Shared.Notifications;

public interface INotificationMessage
{
}