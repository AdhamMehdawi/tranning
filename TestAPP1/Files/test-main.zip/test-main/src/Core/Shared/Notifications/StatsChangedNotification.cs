namespace FSH.WebApi.Shared.Notifications;

public class StatsChangedNotification : INotificationMessage
{
}