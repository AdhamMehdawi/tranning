global using FSH.WebApi.Application.Common.Models;
global using FSH.WebApi.Infrastructure.Auth.Permissions;
global using FSH.WebApi.Infrastructure.OpenApi;
global using FSH.WebApi.Shared.Authorization;
global using Microsoft.AspNetCore.Authorization;
global using Microsoft.AspNetCore.Mvc;
global using NSwag.Annotations;