﻿namespace FSH.WebApi.Infrastructure.Auth.AzureAd;

internal static class AzureADClaimTypes
{
    public const string ObjectId = "http://schemas.microsoft.com/identity/claims/objectidentifier";
}