﻿namespace FSH.WebApi.Infrastructure.Auth.AzureAd;

internal static class OpenIdConnectClaimTypes
{
    public const string Issuer = "iss";
}