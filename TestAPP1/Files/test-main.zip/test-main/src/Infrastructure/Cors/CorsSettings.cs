namespace FSH.WebApi.Infrastructure.Common.Settings;

public class CorsSettings
{
    public string? Angular { get; set; }
    public string? Blazor { get; set; }
    public string? React { get; set; }
}