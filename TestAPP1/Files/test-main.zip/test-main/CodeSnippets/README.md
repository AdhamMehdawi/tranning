[![GitHub](https://img.shields.io/github/license/fullstackhero/dotnet-webapi-boilerplate?color=2da44e)](https://github.com/fullstackhero/dotnet-webapi-boilerplate/blob/master/LICENSE)
[![Discord](https://img.shields.io/discord/878181478972928011?color=%237289da&label=Discord&logo=discord&logoColor=%237289da)](https://discord.gg/yQWpShsKrf)
[![FullStackHero.WebAPI.Boilerplate on NuGet](https://img.shields.io/nuget/v/FullStackHero.WebAPI.Boilerplate?label=FullStackHero.WebAPI.Boilerplate)](https://www.nuget.org/packages/FullStackHero.WebAPI.Boilerplate/)
[![Nuget downloads](https://img.shields.io/nuget/dt/FullStackHero.WebAPI.Boilerplate?color=2da44e&label=nuget%20downloads&logo=nuget)](https://www.nuget.org/packages/FullStackHero.WebAPI.Boilerplate/)

<p> In order to add these to your Visual Studio.</p>
<p> Tools -> Code Snippets Manager -> Add-> Select this fodler(CodeSnippets)</p>
